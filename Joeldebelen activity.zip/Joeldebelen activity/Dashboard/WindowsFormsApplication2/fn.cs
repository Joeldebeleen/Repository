﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    class fn
    {
        public static SqlConnection conn = new SqlConnection();
        public static SqlDataAdapter da = new SqlDataAdapter();
        public static DataTable dt = new DataTable();
        public static string sql;
        public static SqlCommand cmd;
        public static SqlDataReader dr;
        public static void connDB()
        {
            conn.Close();


            try
            {
                conn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\acer\Documents\Visual Studio 2013\Projects\WindowsFormsApplication2\WindowsFormsApplication2\Database1.mdf;Integrated Security=True";
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}

