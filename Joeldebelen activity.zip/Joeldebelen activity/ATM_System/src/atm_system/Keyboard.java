/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Keyboard {
        Scanner name = new Scanner (System.in);
        public String getString()
        {
            return name.nextLine();
        }      
        public int getInt()
        {
            return name.nextInt();
        }
        public double getDouble()
        {
            return name.nextDouble();
        }
    }
    
